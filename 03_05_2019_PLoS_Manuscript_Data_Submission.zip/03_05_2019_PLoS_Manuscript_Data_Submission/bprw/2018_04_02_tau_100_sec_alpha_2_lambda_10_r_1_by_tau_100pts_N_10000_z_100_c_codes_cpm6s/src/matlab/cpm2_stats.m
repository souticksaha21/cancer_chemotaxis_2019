clear all

dd = '../../dat/';
v = load([dd 'cpm2.v.dat']);
CI = load([dd 'cpm2.CI.dat']);
CR = load([dd 'cpm2.CR.dat']);

v = v*60*60; % um/h

Z = length(v)
vbar = mean(v)
dv = std(v)/sqrt(Z)
CIbar = mean(CI)
dCI = std(CI)/sqrt(Z)
CRbar = mean(CR)
dCR = std(CR)/sqrt(Z)
