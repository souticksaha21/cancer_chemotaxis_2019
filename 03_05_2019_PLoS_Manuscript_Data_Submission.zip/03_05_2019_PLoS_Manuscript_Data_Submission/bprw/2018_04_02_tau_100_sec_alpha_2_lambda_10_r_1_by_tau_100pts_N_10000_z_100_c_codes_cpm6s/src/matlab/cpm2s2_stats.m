clear all

dd = '../../dat/';

param = load([dd 'cpm2s2.param.dat']);
la_min = param(6);
la_max = param(7);
Na = param(8);
le_min = param(9);
le_max = param(10);
Ne = param(11);

alpha = logspace(la_min,la_max,Na);
epsilon = logspace(le_min,le_max,Ne);

for i = 1:Na
    for j = 1:Ne
        v = load([dd 'cpm2s2_a' num2str(i-1) ...
            '_e' num2str(j-1) '.v.dat']);
        CI = load([dd 'cpm2s2_a' num2str(i-1) ...
            '_e' num2str(j-1) '.CI.dat']);
        CR = load([dd 'cpm2s2_a' num2str(i-1) ...
            '_e' num2str(j-1) '.CR.dat']);

        v = v*60*60; % um/h

        Z = length(v);
        vbar(i,j) = mean(v);
        dv(i,j) = std(v)/sqrt(Z);
        CIbar(i,j) = mean(CI);
        dCI(i,j) = std(CI)/sqrt(Z);
        CRbar(i,j) = mean(CR);
        dCR(i,j) = std(CR)/sqrt(Z);
    end
end

figure(1); clf
imagesc(log10(alpha),log10(epsilon),log10(vbar)')
set(gca,'ydir','normal')
colorbar
xlabel('log_{10} [\alpha (1/um)]')
ylabel('log_{10} [\epsilon (1/um)]')
title('log_{10} [v (um/hr)]')

figure(2); clf
imagesc(log10(alpha),log10(epsilon),CIbar')
set(gca,'ydir','normal')
colorbar
xlabel('log_{10} [\alpha (1/um)]')
ylabel('log_{10} [\epsilon (1/um)]')
title('CI')

figure(3); clf
imagesc(log10(alpha),log10(epsilon),CRbar')
set(gca,'ydir','normal')
colorbar
xlabel('log_{10} [\alpha (1/um)]')
ylabel('log_{10} [\epsilon (1/um)]')
title('CR')

