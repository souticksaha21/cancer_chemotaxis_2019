clear all

lambda = 15;
N = 50;

% theory
n1 = 0:N;
p1 = poisspdf(n1,lambda);

% sampling code
Z = 1e7;
for z = 1:Z
    n = 0;
    q = -log(rand);
    while q < lambda
        q = q - log(rand);
        n = n + 1;
    end
    ns(z) = n;
end
n2 = min(ns):max(ns);
p2 = hist(ns,n2)/Z;

% plot
plot(n1,p1,'b.-',n2,p2,'ro');