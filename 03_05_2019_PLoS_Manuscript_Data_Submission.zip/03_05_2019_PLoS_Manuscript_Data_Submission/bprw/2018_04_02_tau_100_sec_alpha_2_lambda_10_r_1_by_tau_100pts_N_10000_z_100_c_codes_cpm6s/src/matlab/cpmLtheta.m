function LL = cpmLtheta(theta,alphamin,alphamax,...
    epsilonmin,epsilonmax,lambdaAmin,lambdaAmax)

alpha = (alphamax-alphamin)/(1+exp(-theta(1))) + alphamin;
epsilon = (epsilonmax-epsilonmin)/(1+exp(-theta(2))) + epsilonmin;
lambdaA = (lambdaAmax-lambdaAmin)/(1+exp(-theta(3))) + lambdaAmin;

LL = cpmL(alpha,epsilon,lambdaA);
