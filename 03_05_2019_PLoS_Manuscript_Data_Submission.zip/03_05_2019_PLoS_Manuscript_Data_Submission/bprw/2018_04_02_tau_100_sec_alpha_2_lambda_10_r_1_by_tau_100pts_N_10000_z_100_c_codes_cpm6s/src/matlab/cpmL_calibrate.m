clear all

% compile
mex cpmL.cpp

% initialize
alpha0 = 1;
epsilon0 = 4;
lambdaA0 = 1e-3;

% limits
alphamin = 1e-2;
alphamax = 1e1;
epsilonmin = 1e-2;
epsilonmax = 1e3;
lambdaAmin = 1e-5;
lambdaAmax = 1;

% convert to theta
theta0 = [log((alpha0-alphamin)/(alphamax-alpha0))
    log((epsilon0-epsilonmin)/(epsilonmax-epsilon0))
    log((lambdaA0-lambdaAmin)/(lambdaAmax-lambdaA0))];

% minimize
fun = @(theta)cpmLtheta(theta,alphamin,alphamax,...
    epsilonmin,epsilonmax,lambdaAmin,lambdaAmax);
thetastar = fminsearch(fun,theta0);

% convert optimal parameters back
alphastar = (alphamax-alphamin)/(1+exp(-theta(1))) + alphamin
epsilonstar = (epsilonmax-epsilonmin)/(1+exp(-theta(2))) + epsilonmin
lambdaAstar = (lambdaAmax-lambdaAmin)/(1+exp(-theta(3))) + lambdaAmin
