clear all

dd = '../../dat/';
x = load([dd 'x.dat']);

hist(x,1:15)