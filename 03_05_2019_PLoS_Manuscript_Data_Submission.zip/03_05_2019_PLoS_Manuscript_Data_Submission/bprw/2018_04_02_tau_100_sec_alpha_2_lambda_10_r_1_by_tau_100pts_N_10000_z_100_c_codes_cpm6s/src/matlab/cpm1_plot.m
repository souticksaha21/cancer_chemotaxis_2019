clear all

dd = '../../dat/';
param = load([dd 'cpm1.param.dat']);
X = load([dd 'cpm1.X.dat']);
Y = load([dd 'cpm1.Y.dat']);
Np = load([dd 'cpm1.Np.dat']);
t = load([dd 'cpm1.t.dat']);

R = param(1);
a = param(2);
tau = param(3);
T = param(4);
x = X*a;
y = Y*a;

ms = 3;
plot(x(1,1:Np(1)),y(1,1:Np(1)),'ks',...
    'markersize',ms,'markerfacecolor','k')
xlim([-100 100])
ylim([-100 100])
xlabel('x position (um)')
ylabel('y position (um)')
title(['t = ' num2str(round(t(1)/60)) ' min'])
drawnow; pause

for i = 2:length(t);
    plot(x(i,1:Np(i)),y(i,1:Np(i)),'ks',...
        'markersize',ms,'markerfacecolor','k')
    xlim([-100 100])
    ylim([-100 100])
    xlabel('x position (um)')
    ylabel('y position (um)')
    title(['t = ' num2str(round(t(i)/60)) ' min'])
    drawnow; pause
end