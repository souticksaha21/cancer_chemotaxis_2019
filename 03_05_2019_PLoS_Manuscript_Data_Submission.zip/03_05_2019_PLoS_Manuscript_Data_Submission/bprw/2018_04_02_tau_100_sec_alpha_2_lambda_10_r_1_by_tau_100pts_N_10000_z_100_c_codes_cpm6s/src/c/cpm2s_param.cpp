double R = 10; // um, cell radius (half side length -- area = 4*R^2)
double a = 2; // um, lattice size
double tau = 100; //1; // s, MC time step
double d = a; // um, pixel depth
double T = 9*60*60+1; // s, total time
double deltat = 15*60; // s, measurement interval
double lambdaA = 1e-3; // 1/um^4, area deviation penalty
double c0 = 2.5*.6; // 1/um^-3, concentration at x = 0
double g = 5*.6/1e3; // 1/um^4, gradient
int Z = 100; // number of trials

double la_min = -1; // min log10 alpha
double la_max = 1; // max log10 alpha
int Na = 5; // number of alpha values
double le_min = -1; // min log10 epsilon
double le_max = 2; // max log10 epsilon
int Ne = 8; // number of epsilon values

char base[] = "../../dat/cpm2s2";
