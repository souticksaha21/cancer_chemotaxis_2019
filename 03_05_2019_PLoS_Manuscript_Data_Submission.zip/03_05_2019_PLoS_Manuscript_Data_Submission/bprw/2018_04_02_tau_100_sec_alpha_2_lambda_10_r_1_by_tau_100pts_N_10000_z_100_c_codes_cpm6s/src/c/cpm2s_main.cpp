#include "stdio.h"
#include "math.h"
#include "mersenne_twister.hpp"

#include "cpm2s_param.cpp"
// includes alpha, lambda_A, epsilon; log scan over alpha and epsilon

int main(void)
{

  // instantiate random number generator
  MTRand rg(1);

  // for file writing
  FILE *fpparam, *fpX, *fpY, *fpNp, *fpt, *fpv, *fpCI, *fpCR;
  char filename[FILENAME_MAX];

  // allocate variables
  int i, j, k, l, z, ia, ie;
  int xmin, xmax, ymin, ymax, x1, x2, y1, y2;
  int r1, r2, r3;
  double r4, r5;
  double t; // s, time
  int sigma1, sigma2; // pixel identities (0 = ECM, 1 = cell)
  int NT; // number of trials in a MC time step
  double A0 = 4*R*R; // cell area (um)
  int N = (int) A0/a/a; // average number of cell pixels
  int L = (int) 2*R/a; // initial cell length in pixels
  int kmax = 10*N; // max pixel number (for file writing)
  int X[kmax]; // cell pixel x locations
  int Y[kmax]; // cell pixel y locations
  int Np; // current number of cell pixels
  int dN; // perimeter change
  double du, w; // energy change and work
  int kn; // index of neighbor
  int nn; // number of neighbor's neighbors
  double tn; // next measurement time
  int b = 1; // buffer for sampling area
  int Nm = (int) T/deltat; // number of measurements (excluding t = 0)
  double xcm; // center of mass x position
  double ycm; // center of mass y position
  double xcms[Nm+1]; // vector of center of mass x positions
  double ycms[Nm+1]; // vector of center of mass y positions
  int icm; // index for cm vectors
  double dxcm, dycm; // changes in CM components
  double v; // speed
  double CI; // chemotactic index
  double CR; // chemotactic ratio
  double vsum, dist;
  int ns[kmax]; // molecule number samples
  double nbar; // mean of ns
  double lambda, p; // for Poisson sample generation
  double qx, qy; // components of sensing vector
  double alpha, epsilon; // scanned parameters

  // write parameters
  sprintf(filename,"%s.param.dat",base);
  fpparam = fopen(filename,"w");
  fprintf(fpparam,"%f\n",R);
  fprintf(fpparam,"%f\n",a);
  fprintf(fpparam,"%f\n",tau);
  fprintf(fpparam,"%f\n",T);
  fprintf(fpparam,"%f\n",deltat);
  fprintf(fpparam,"%f\n",la_min);
  fprintf(fpparam,"%f\n",la_max);
  fprintf(fpparam,"%d\n",Na);
  fprintf(fpparam,"%f\n",le_min);
  fprintf(fpparam,"%f\n",le_max);
  fprintf(fpparam,"%d\n",Ne);
  fclose(fpparam);

  // loop over parameters
  for (ia = 0; ia < Na; ia++){
    alpha = pow(10,la_min + ia*(la_max-la_min)/(Na-1));
    printf("alpha = %f\n",alpha);
    
    for (ie = 0; ie < Ne; ie++){
      epsilon = pow(10,le_min + ie*(le_max-le_min)/(Ne-1));
      printf("epsilon = %f\n",epsilon);

      // open stat files
      sprintf(filename,"%s_a%d_e%d.v.dat",base,ia,ie);
      fpv = fopen(filename,"w");
      sprintf(filename,"%s_a%d_e%d.CI.dat",base,ia,ie);
      fpCI = fopen(filename,"w");
      sprintf(filename,"%s_a%d_e%d.CR.dat",base,ia,ie);
      fpCR = fopen(filename,"w");
      
      // loop over trials
      for (z = 0; z < Z; z++){
	printf("z = %d\n",z);
	
	// initialize cell pixel locations (with buffer zeros at end)
	Np = N;
	for (i = 0; i < L; i++){
	  for (j = 0; j < L; j++){
	    k = j + L*i;
	    X[k] = i;
	    Y[k] = j;
	  }
	}
	for (k = Np; k < kmax; k++){
	  X[k] = 0;
	  Y[k] = 0;
	}
	
	// calculate center of mass
	xcm = 0;
	ycm = 0;
	for (k = 0; k < Np; k++){
	  xcm = xcm + X[k];
	  ycm = ycm + Y[k];
	}
	xcm = xcm/Np;
	ycm = ycm/Np;
	
	// simulate
	t = 0;
	tn = 0;
	icm = 0;
	while (t < T){
	  
	  // every deltat
	  if (t >= tn){
	    
	    // record (x,y) for center of mass
	    xcms[icm] = xcm;
	    ycms[icm] = ycm;
	    tn = tn + deltat;
	    icm = icm + 1;
	  }
	  
	  // get Poisson sample at each pixel
	  // note that if lambda < 0, then n = 0;
	  nbar = 0;
	  for (k = 0; k < Np; k++){
	    lambda = (c0 + g*X[k])*a*a*a;
	    ns[k] = 0;
	    r5 = rg.randDblExc();
	    p = -log(r5);
	    while (p < lambda){
	      r5 = rg.randDblExc();
	      p = p - log(r5);
	      ns[k] = ns[k] + 1;
	    }
	    nbar = nbar + ns[k];	
	  }
	  nbar = nbar/Np;
	  
	  // calculate sensing vector
	  qx = 0;
	  qy = 0;
	  for (k = 0; k < Np; k++){
	    qx = qx + (ns[k]-nbar)*(X[k]-xcm)
	      /sqrt((X[k]-xcm)*(X[k]-xcm) + (Y[k]-ycm)*(Y[k]-ycm));
	    qy = qy + (ns[k]-nbar)*(Y[k]-ycm)
	      /sqrt((X[k]-xcm)*(X[k]-xcm) + (Y[k]-ycm)*(Y[k]-ycm));
	  }
	  qx = qx/Np;
	  qy = qy/Np;
	  
	  // find min/max x and y locations
	  xmin = X[0];
	  xmax = X[0];
	  ymin = Y[0];
	  ymax = Y[0];
	  for (k = 0; k < Np; k++){
	    if (X[k] < xmin){ xmin = X[k]; }
	    if (X[k] > xmax){ xmax = X[k]; }
	    if (Y[k] < ymin){ ymin = Y[k]; }
	    if (Y[k] > ymax){ ymax = Y[k]; }
	  }
	  
	  // calculate number of samples
	  NT = (xmax-xmin+2*b+1)*(ymax-ymin+2*b+1);
	  
	  // loop over samples
	  for (l = 0; l < NT; l++){
	    
	    // randomly pick a pixel
	    r1 = rg.randInt(xmax-xmin+2*b);
	    r2 = rg.randInt(ymax-ymin+2*b);
	    x1 = (int) (xmin-b + r1);
	    y1 = (int) (ymin-b + r2);
	    
	    // randomly pick a neighbor of that pixel
	    r3 = rg.randInt(3);
	    if (r3 == 0){ x2 = x1-1; y2 = y1; }
	    if (r3 == 1){ x2 = x1+1; y2 = y1; }
	    if (r3 == 2){ x2 = x1; y2 = y1-1; }
	    if (r3 == 3){ x2 = x1; y2 = y1+1; }
	    
	    // find identities of pixel and neighbor
	    sigma1 = 0;
	    sigma2 = 0;
	    for (k = 0; k < Np; k++){
	      if ((X[k] == x1) && (Y[k] == y1)){
		sigma1 = 1;
	      }
	      if ((X[k] == x2) && (Y[k] == y2)){
		sigma2 = 1;
		// save neighbor's index in case it becomes ECM
		kn = k;
	      }
	    }
	    
	    // if indentities different, try to copy pixel identity to neighbor
	    // case 1: pixel is cell and neighbor is ECM
	    if ((sigma1 == 1) && (sigma2 == 0)){
	      
	      // find perimeter change based on neighbor's neighbors
	      nn = 0;
	      for (k = 0; k < Np; k++){
		if ((X[k] == x2+1) && (Y[k] == y2)){
		  nn = nn + 1;
		}
		if ((X[k] == x2-1) && (Y[k] == y2)){
		  nn = nn + 1;
		}
		if ((X[k] == x2) && (Y[k] == y2+1)){
		  nn = nn + 1;
		}
		if ((X[k] == x2) && (Y[k] == y2-1)){
		  nn = nn + 1;
		}
	      }
	      if (nn == 1){ dN = 2; }
	      if (nn == 2){ dN = 0; }
	      if (nn == 3){ dN = -2; }
	      if (nn == 4){ dN = -4; }
	      if (nn > 4){ printf("nn = %d\n",nn); }
	      if (nn == 0){ printf("nn = %d\n",nn); }
	      
	      // calculate energy change
	      du = alpha*a*dN
		+ lambdaA*a*a*a*a*((Np+1-N)*(Np+1-N) - (Np-N)*(Np-N));
	      
	      // calculate center of mass change
	      dxcm = (x2-xcm)/(Np+1);
	      dycm = (y2-ycm)/(Np+1);
	      
	      // calculate work
	      w = epsilon*(dxcm*qx + dycm*qy);
	      
	      // attempt the move
	      r4 = rg.rand();
	      if (r4 < exp(-du+w)){
		X[Np] = x2;
		Y[Np] = y2;
		xcm = xcm + dxcm;
		ycm = ycm + dycm;
		Np = Np + 1;
	      }
	    }
	    
	    // case 2: pixel is ECM and neighbor is cell
	    if ((sigma1 == 0) && (sigma2 == 1)){
	      
	      // find perimeter change based on neighbor's neighbors
	      nn = 0;
	      for (k = 0; k < Np; k++){
		if ((X[k] == x2+1) && (Y[k] == y2)){
		  nn = nn + 1;
		}
		if ((X[k] == x2-1) && (Y[k] == y2)){
		  nn = nn + 1;
		}
		if ((X[k] == x2) && (Y[k] == y2+1)){
		  nn = nn + 1;
		}
		if ((X[k] == x2) && (Y[k] == y2-1)){
		  nn = nn + 1;
		}
	      }
	      if (nn == 0){ dN = -4; }
	      if (nn == 1){ dN = -2; }
	      if (nn == 2){ dN = 0; }
	      if (nn == 3){ dN = 2; }
	      if (nn > 3){ printf("nn = %d\n",nn); }
	      
	      // calculate energy change
	      du = alpha*a*dN
		+ lambdaA*a*a*a*a*((Np-1-N)*(Np-1-N) - (Np-N)*(Np-N));
	      
	      // calculate center of mass change
	      dxcm = -(x2-xcm)/(Np-1);
	      dycm = -(y2-ycm)/(Np-1);
	      
	      // calculate work
	      w = epsilon*(dxcm*qx + dycm*qy);
	      
	      // attempt the move
	      r4 = rg.rand();
	      if (r4 < exp(-du+w)){
		// remove the neighbor pixel from the cell list and shift
		for (k = kn; k < Np-1; k++){
		  X[k] = X[k+1];
		  Y[k] = Y[k+1];
		}
		X[Np-1] = 0;
		Y[Np-1] = 0;
		xcm = xcm + dxcm;
		ycm = ycm + dycm;
		Np = Np - 1;
	      }
	    }
	  }
	  
	  // update time
	  t = t + tau; 
	}
	
	// compute statistics
	// speed
	vsum = 0;
	for (i = 0; i < Nm; i++){
	  vsum = vsum
	    + a*sqrt((xcms[i+1]-xcms[i])*(xcms[i+1]-xcms[i]) 
		     + (ycms[i+1]-ycms[i])*(ycms[i+1]-ycms[i]))/deltat;
	}
	v = vsum/Nm;
	
	// CI
	CI = (xcms[Nm]-xcms[0])/
	  sqrt((xcms[Nm]-xcms[0])*(xcms[Nm]-xcms[0])
	       + (ycms[Nm]-ycms[0])*(ycms[Nm]-ycms[0]));
	
	// CR
	dist = 0;
	for (i = 0; i < Nm; i++){
	  dist = dist + sqrt((xcms[i+1]-xcms[i])*(xcms[i+1]-xcms[i])
			     + (ycms[i+1]-ycms[i])*(ycms[i+1]-ycms[i]));
	}
	CR = sqrt((xcms[Nm]-xcms[0])*(xcms[Nm]-xcms[0])
		  + (ycms[Nm]-ycms[0])*(ycms[Nm]-ycms[0]))/dist;
	
	// write stats
	fprintf(fpv,"%f\n",v);
	fprintf(fpCI,"%f\n",CI);
	fprintf(fpCR,"%f\n",CR);
	
      }
      
      // close stat files
      fclose(fpv);
      fclose(fpCI);
      fclose(fpCR);
    }
  }

  return 0;

}
