#include "stdio.h"
#include "math.h"
#include "mersenne_twister.hpp"

#include "cpm1_param.cpp"
// includes alpha, lambda_A

int main(void)
{

  // instantiate random number generator
  MTRand rg(1);

  // for file writing
  FILE *fpparam, *fpX, *fpY, *fpNp, *fpt, *fpv, *fpCI, *fpCR;
  char filename[FILENAME_MAX];

  // allocate variables
  int i, j, k, l, z;
  int xmin, xmax, ymin, ymax, x1, x2, y1, y2;
  int r1, r2, r3;
  double r4;
  double t; // s, time
  int sigma1, sigma2; // pixel identities (0 = ECM, 1 = cell)
  int NT; // number of trials in a MC time step
  double A0 = 4*R*R; // cell area (um)
  int N = (int) A0/a/a; // average number of cell pixels
  int L = (int) 2*R/a; // initial cell length in pixels
  int kmax = 10*N; // max pixel number (for file writing)
  int X[kmax]; // cell pixel x locations
  int Y[kmax]; // cell pixel y locations
  int Np; // current number of cell pixels
  int dN; // perimeter change
  double du; // energy change
  int kn; // index of neighbor
  int nn; // number of neighbor's neighbors
  double tn; // next measurement time
  int b = 1; // buffer for sampling area
  int Nm = (int) T/deltat; // number of measurements (excluding t = 0)
  double xcm[Nm+1]; // center of mass x positions
  double ycm[Nm+1]; // center of mass y positions
  int icm; // index for cm vectors
  double v; // speed
  double CI; // chemotactic index
  double CR; // chemotactic ratio
  double vsum, dist;

  // write parameters
  sprintf(filename,"%s.param.dat",base);
  fpparam = fopen(filename,"w");
  fprintf(fpparam,"%f\n",R);
  fprintf(fpparam,"%f\n",a);
  fprintf(fpparam,"%f\n",tau);
  fprintf(fpparam,"%f\n",T);
  fprintf(fpparam,"%f\n",deltat);
  fclose(fpparam);

  // open stat files
  sprintf(filename,"%s.v.dat",base);
  fpv = fopen(filename,"w");
  sprintf(filename,"%s.CI.dat",base);
  fpCI = fopen(filename,"w");
  sprintf(filename,"%s.CR.dat",base);
  fpCR = fopen(filename,"w");

  // loop over trials
  for (z = 0; z < Z; z++){
    printf("z = %d\n",z);

    // initialize cell pixel locations (with buffer zeros at end)
    Np = N;
    for (i = 0; i < L; i++){
      for (j = 0; j < L; j++){
	k = j + L*i;
	X[k] = i;
	Y[k] = j;
      }
    }
    for (k = Np; k < kmax; k++){
      X[k] = 0;
      Y[k] = 0;
    }
    
    // open movie files
    if (z == zmov){
      sprintf(filename,"%s.X.dat",base);
      fpX = fopen(filename,"w");
      sprintf(filename,"%s.Y.dat",base);
      fpY = fopen(filename,"w");
      sprintf(filename,"%s.Np.dat",base);
      fpNp = fopen(filename,"w");
      sprintf(filename,"%s.t.dat",base);
      fpt = fopen(filename,"w");
    }

    // simulate
    t = 0;
    tn = 0;
    icm = 0;
    while (t < T){

      // every deltat
      if (t >= tn){

	// write movie data
	if (z == zmov){
	  for (k = 0; k < kmax; k++){
	    fprintf(fpX,"%d\t",X[k]);
	    fprintf(fpY,"%d\t",Y[k]);
	  }
	  fprintf(fpX,"\n");
	  fprintf(fpY,"\n");
	  fprintf(fpNp,"%d\n",Np);
	  fprintf(fpt,"%f\n",t);
	}

	// record (x,y) for center of mass
	xcm[icm] = 0;
	ycm[icm] = 0;
	for (k = 0; k < Np; k++){
	  xcm[icm] = xcm[icm] + X[k];
          ycm[icm] = ycm[icm] + Y[k];
	}
	xcm[icm] = xcm[icm]/Np;
	ycm[icm] = ycm[icm]/Np;

	tn = tn + deltat;
	icm = icm + 1;
      }

      // find min/max x and y locations
      xmin = X[0];
      xmax = X[0];
      ymin = Y[0];
      ymax = Y[0];
      for (k = 0; k < Np; k++){
	if (X[k] < xmin){	xmin = X[k]; }
	if (X[k] > xmax){	xmax = X[k]; }
	if (Y[k] < ymin){	ymin = Y[k]; }
	if (Y[k] > ymax){ ymax = Y[k]; }
      }
      
      // calculate number of samples
      NT = (xmax-xmin+2*b+1)*(ymax-ymin+2*b+1);
      
      // loop over samples
      for (l = 0; l < NT; l++){
	
	// randomly pick a pixel
	r1 = rg.randInt(xmax-xmin+2*b);
	r2 = rg.randInt(ymax-ymin+2*b);
	x1 = (int) (xmin-b + r1);
	y1 = (int) (ymin-b + r2);
	
	// randomly pick a neighbor of that pixel
	r3 = rg.randInt(3);
	if (r3 == 0){ x2 = x1-1; y2 = y1; }
	if (r3 == 1){ x2 = x1+1; y2 = y1; }
	if (r3 == 2){ x2 = x1; y2 = y1-1; }
	if (r3 == 3){ x2 = x1; y2 = y1+1; }
	
	// find identities of pixel and neighbor
	sigma1 = 0;
	sigma2 = 0;
	for (k = 0; k < Np; k++){
	  if ((X[k] == x1) && (Y[k] == y1)){
	    sigma1 = 1;
	  }
	  if ((X[k] == x2) && (Y[k] == y2)){
	    sigma2 = 1;
	    // save neighbor's index in case it becomes ECM
	    kn = k;
	  }
	}
	
	// if indentities different, try to copy pixel identity to neighbor
	// case 1: pixel is cell and neighbor is ECM
	if ((sigma1 == 1) && (sigma2 == 0)){
	  
	  // find perimeter change based on neighbor's neighbors
	  nn = 0;
	  for (k = 0; k < Np; k++){
	    if ((X[k] == x2+1) && (Y[k] == y2)){
	      nn = nn + 1;
	    }
	    if ((X[k] == x2-1) && (Y[k] == y2)){
	      nn = nn + 1;
	    }
	    if ((X[k] == x2) && (Y[k] == y2+1)){
	      nn = nn + 1;
	    }
	    if ((X[k] == x2) && (Y[k] == y2-1)){
	      nn = nn + 1;
	    }
	  }
	  if (nn == 1){ dN = 2; }
	  if (nn == 2){ dN = 0; }
	  if (nn == 3){ dN = -2; }
	  if (nn == 4){ dN = -4; }
	  if (nn > 4){ printf("nn = %d\n",nn); }
	  if (nn == 0){ printf("nn = %d\n",nn); }
	  
	  // calculate energy change
	  du = alpha*a*dN
	    + lambdaA*a*a*a*a*((Np+1-N)*(Np+1-N) - (Np-N)*(Np-N));
	  
	  // attempt the move
	  r4 = rg.rand();
	  if (r4 < exp(-du)){
	    X[Np] = x2;
	    Y[Np] = y2;
	    Np = Np + 1;
	  }
	}
	
	// case 2: pixel is ECM and neighbor is cell
	if ((sigma1 == 0) && (sigma2 == 1)){
	  
	  // find perimeter change based on neighbor's neighbors
	  nn = 0;
	  for (k = 0; k < Np; k++){
	    if ((X[k] == x2+1) && (Y[k] == y2)){
	      nn = nn + 1;
	    }
	    if ((X[k] == x2-1) && (Y[k] == y2)){
	      nn = nn + 1;
	    }
	    if ((X[k] == x2) && (Y[k] == y2+1)){
	      nn = nn + 1;
	    }
	    if ((X[k] == x2) && (Y[k] == y2-1)){
	      nn = nn + 1;
	    }
	  }
	  if (nn == 0){ dN = -4; }
	  if (nn == 1){ dN = -2; }
	  if (nn == 2){ dN = 0; }
	  if (nn == 3){ dN = 2; }
	  if (nn > 3){ printf("nn = %d\n",nn); }
	  
	  // calculate energy change
	  du = alpha*a*dN
	    + lambdaA*a*a*a*a*((Np-1-N)*(Np-1-N) - (Np-N)*(Np-N));
	  
	  // attempt the move
	  r4 = rg.rand();
	  if (r4 < exp(-du)){
	    // remove the neighbor pixel from the cell list and shift
	    for (k = kn; k < Np-1; k++){
	      X[k] = X[k+1];
	      Y[k] = Y[k+1];
	    }
	    X[Np-1] = 0;
	    Y[Np-1] = 0;
	    Np = Np - 1;
	  }
	}
      }
      
      // update time
      t = t + tau;
      
    }
   
    // close movie files
    if (z == zmov){
      fclose(fpX);
      fclose(fpY);
      fclose(fpNp);
      fclose(fpt);
    }

    // compute statistics
    // speed
    vsum = 0;
    for (i = 0; i < Nm; i++){
      vsum = vsum + a*sqrt((xcm[i+1]-xcm[i])*(xcm[i+1]-xcm[i]) 
			   + (ycm[i+1]-ycm[i])*(ycm[i+1]-ycm[i]))/deltat;
    }
    v = vsum/Nm;

    // CI
    CI = (xcm[Nm]-xcm[0])/
      sqrt((xcm[Nm]-xcm[0])*(xcm[Nm]-xcm[0])
	   + (ycm[Nm]-ycm[0])*(ycm[Nm]-ycm[0]));

    // CR
    dist = 0;
    for (i = 0; i < Nm; i++){
      dist = dist + sqrt((xcm[i+1]-xcm[i])*(xcm[i+1]-xcm[i])
			 + (ycm[i+1]-ycm[i])*(ycm[i+1]-ycm[i]));
    }
    CR = sqrt((xcm[Nm]-xcm[0])*(xcm[Nm]-xcm[0])
		 + (ycm[Nm]-ycm[0])*(ycm[Nm]-ycm[0]))/dist;

    // write stats
    fprintf(fpv,"%f\n",v);
    fprintf(fpCI,"%f\n",CI);
    fprintf(fpCR,"%f\n",CR);

  }

  // close stat files
  fclose(fpv);
  fclose(fpCI);
  fclose(fpCR);
  
  return 0;

}
