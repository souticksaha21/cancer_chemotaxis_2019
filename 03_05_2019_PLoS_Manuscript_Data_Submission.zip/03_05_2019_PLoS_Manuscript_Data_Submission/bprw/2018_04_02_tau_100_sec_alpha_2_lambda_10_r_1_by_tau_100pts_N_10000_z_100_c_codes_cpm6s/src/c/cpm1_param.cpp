double R = 10; // um, cell radius (half side length -- area = 4*R^2)
double a = 2; // um, lattice size
double tau = 1; // s, MC time step
double d = a; // um, pixel depth
double T = 9*60*60+1; // s, total time
double deltat = 15*60; // s, measurement interval
double alpha = 1; // 1/um, cell-ECM line energy
double lambdaA = 1e-3; // 1/um^4, area deviation penalty
int Z = 100; // number of trials
int zmov = 0; // which trial to record movie data

char base[] = "../../dat/cpm1";
